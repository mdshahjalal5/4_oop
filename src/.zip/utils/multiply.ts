const multiply = (param1: number, param2: number): number => {
  return param1 * param2;
};

export default multiply;
