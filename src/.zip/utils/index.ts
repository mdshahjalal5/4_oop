import addTwo from "./add";
import subtract from "./substract";
import multiply from "./multiply";
import average from "./average";

export default {
  addTwo,
  subtract,
  multiply,
  average,
};
