const subtract = (param1: number, param2: number): number => {
  return param1 - param2;
};

export default subtract;
